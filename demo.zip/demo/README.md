# AES_API
AES encrypt and decrypt with SpringBoot

Passed the test with encrypt and decrypt method
![image](https://user-images.githubusercontent.com/58870660/154845829-2814039a-6ea7-4c5f-8947-c9fad12d4bf5.png)
